<?php

namespace App\Data;
use Illuminate\Database\Eloquent\Model;

class Respuesta extends Model
{
    public $Codigo;
    public $Mensaje;
    public $Data;
}
